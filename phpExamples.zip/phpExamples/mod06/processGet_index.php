<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<title>顯示商品資訊</title>
<style type="text/css">
#main {
	position: absolute;
	top: 110px;
	left: 120px;
}
#sub {
	position: absolute;
	top: 360px;
	left: 210px;
}
</style>
</head>
<body bgcolor='#e0e0f0'>
	<a href='processGet.php?numA=100&numB=236'>按這裡來執行processGet.php</a>
		
</body>
</html>
