<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<title>Get Demo</title>
</head>
<?php
   $a = $_GET['numA'];
   $b = $_GET['numB'];   
   $c = $a + $b;
   echo "兩數的總和為 $c" ;    
?>
<body>
</body>
</html>
