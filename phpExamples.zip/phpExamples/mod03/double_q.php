<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
</head>
<body> 
    <?php
    echo("Today is fine!<br>");
    echo("今天天氣很好！<br>");
    echo("Happy Birthday.\n<br>");
    echo("Happy Birthday.\\n<br>");
    echo("My name is \"Mary\".<br>");
    echo("My name is 'Mary'.<br>");
    //echo("My name is "Mary".<br>");  // 此行語法是錯誤的
    $str = "Mary";
    echo("There are many {$str}s in my school.<br>");
    echo("金錢符號是 \$_$ !<br>");
	?>
  </body>
</html>