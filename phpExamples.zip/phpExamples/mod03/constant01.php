<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod03/constant01.php</title>
  </head>
  <body>
    <?php
		  const PI =  3.1415962;
		  $r = 10 ;
		  $area = PI * $r * $r ;    // * 表示乘法運算子
		  echo "area=" . $area ;
    ?>
</body> 
</html>