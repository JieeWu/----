<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod03/variable03.php</title>
  </head>
  <body>

<?php             // ch03/variable03.php
    $x = 100 ;    // $x 表示某個變數， 其值目前為 100
    $y = $x + 1 ; 
    $y = $y + 1 ;      
    echo "$x=" .$x . "，  $y=" .$y . "<br>";
 	echo '$x=' .$x . '，  $y=' .$y . "<br>"; ;
?>
</body> 
</html>