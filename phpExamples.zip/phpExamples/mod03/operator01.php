<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod03/operator01.php</title>
  </head>
  <body> 
    <?php              
	  $x = 30 ; 
	  $y = 30 ;
      echo '($x == $y) --->' . ($x == $y) ;	// 印出 1
      echo   "<br>" ;	  	  	  	  
	  $x = 40 ; 
	  $y = 30 ;
      echo '($x > $y) --->' . ($x > $y) ;	// 印出 1
      echo   "<br>" ;	  	  	  	  	  
      echo '($x != $y) --->' . ($x != $y) ;	// 印出 1
      echo   "<br>" ;	
    ?>

</body> 
</html>