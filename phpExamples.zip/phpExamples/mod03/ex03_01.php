<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>練習ex03_01</title>
  </head>
  <body>
    <?php
         echo("Hello World!， 大家好 <br>");
         echo "伺服器上的時間為" . date(" Y/m/d H:i:s") ;
    ?>
   </body> 
</html>
