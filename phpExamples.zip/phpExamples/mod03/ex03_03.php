<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>練習ex03_03</title>
  </head>
  <body>
    <?php
         $x = 18;
         $y = 5.4;
         echo "長方形邊長總和為" .  2 * ($x + $y) . "<br>";
         echo "長方形面積為  " . $x * $y . "<br>";
    ?>
   </body> 
</html>
