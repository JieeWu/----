<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>練習ex03_02</title>
  </head>
  <body>
    <?php
         echo("Hello World， 大家好 <br>");
         echo("Hello World， 大家好 <br>");
         echo("Hello World， 大家好 <br>");
         echo("Hello World， 大家好 <br>");
         echo("Hello World， 大家好 <br>");
    ?>
   </body> 
</html>
