<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<title>explode函數</title>
</head>
<?php
$str='Kitty|Mickey|Snoopy|Garfield';
$arr1 = explode('|', $str) ; 
print_r($arr1);  
?>
<body>
</body>
</html>

