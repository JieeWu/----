<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod03/variable02.php</title>
  </head>
  <body>

<?php    // ch03/variable02.php
         $age = "十八歲";
         $age  = 18;
         echo  "年齡為" . $age ;
?>

</body> 
</html> 