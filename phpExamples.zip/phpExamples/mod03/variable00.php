<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod03/variable00.php</title>
  </head>
  <body>
<?php     // ch03/variable00.php
         $user = "mary"; 
         $age  = 18;
         echo "姓名為" . $user . " , 年齡為" . $age ." <br>";
         echo "姓名為$user , 年齡為$age <br>";
         //由上面兩行敘述可比較出雙引號字串的優點
?>
</body>  
</html>