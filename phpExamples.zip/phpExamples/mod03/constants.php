<?php    // 檔名為constants.php
    define('VAT', 0.05);
    define('NL', "<br/>");
?>