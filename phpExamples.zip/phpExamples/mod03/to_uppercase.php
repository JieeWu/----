<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<title>explode函數</title>
</head>
<?php
$str='this is real';
echo("字串中的第一個字母大寫: " . ucfirst( $str)) . "<br>"; 
echo("字串中的每一字第一個字母大寫: " . ucwords( $str)) . "<br>"; 
  
?>
<body>
</body>
</html>
