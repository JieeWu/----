<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod03/variable01.php</title>
  </head>
  <body>
<?php     
      // ch03/variable01.php
      $today = "星期一";
      $today = "星期二";
      echo "今天是" . $today;
?>
</body> 
</html> 