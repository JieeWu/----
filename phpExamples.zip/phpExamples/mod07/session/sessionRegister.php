<?php
    session_start();
    $aaa = '123456';
    session_register($aaa);
?>