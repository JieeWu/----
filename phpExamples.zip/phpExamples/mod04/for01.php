<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>ch04/for01.php</title>
  </head>
  <body>
<?php
   for ($x = 1 ; $x <= 5; $x++) {
	  echo "Hello， World， 大家好!!!" ;
	  echo "<br>";
   }
?>
</body> 
</html>