<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>ch04/for00.php</title>
  </head>
  <body>
<?php
  for ($x = 1 ; $x <= 6; $x++) {
  	echo rand (1, 49) ;
  	echo "<br>";
  }
?>
</body> 
</html>
