<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<title>Untitled Document</title>
</head>
<?php
     $x = 1; $sum=0 ;
     do {
         $sum = $sum + $x ;
		 $x++;
     } while ( $x <= 10 );
     echo "1 加到 10 的總和=" . $sum . "<br>";  
?>
<body>
</body>
</html>
