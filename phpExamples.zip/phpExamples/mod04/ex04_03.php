<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>練習ex04_03</title>
  </head>
  <body>
    <?php
       for ($y = 1 ; $y <= 3 ; $y++  ) {
           for ($x = 1 ; $x <= 5 ; $x++  ) {
               echo  "$y, $x<br>";
           }   
       }
    ?>
   </body> 
</html>
