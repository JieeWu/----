<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>ch04/for03.php</title>
  </head>
  <body>
  <?php               // ch04/for03.php
  for ( $x = 1; $x <= 9;  $x++ ) {
     echo "x=$x<br>";
  }
  ?>
  <hr>
  <?php               
  for ( $x = 0; $x < 9;  $x++ ) {
     echo "x=$x<br>";
  }
  ?>
   </body> 
</html>