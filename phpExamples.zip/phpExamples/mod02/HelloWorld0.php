<!DOCTYPE html>
<html>
  <head>
  	<meta charset='utf-8'>
  	<title>我的第一個 PHP程式</title>
  </head>
  <body>
       <?php
            echo("Hello World!， 大家好 ");
       ?>
  </body>      
</html>