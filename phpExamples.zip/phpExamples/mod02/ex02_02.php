<!DOCTYPE html>
<html>
   <head>
      <meta charset='utf-8'>
      <title>練習ex02_02</title>
   </head>
   <body>
       <?php
            echo "<center>";
            echo "<table border='1'>";
            echo "<tr>";
            echo "<td width='40' align='center'>春</td><td width='40' align='CENTER'>夏</td><td width='40' align='CENTER'>秋</td><td width='40' align='CENTER'>冬</td>";
            echo "</tr>";
            echo "<tr>";
            echo "<td width='40' align='center'>梅</td><td width='40' align='CENTER'>蘭</td><td width='40' align='CENTER'>竹</td><td width='40' align='CENTER'>菊</td>";
            echo "</tr>";
            echo "</table>";
       ?>
  </body> 
</html>