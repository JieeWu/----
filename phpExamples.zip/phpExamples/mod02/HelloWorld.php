<!DOCTYPE html>
<html>
  <head>
  	<meta charset='utf-8'>
  	<title>我的第一個 PHP程式</title>
  </head>
  <body>
       <?php
            /*
                                   這是一個簡單的範例程式
            */
            echo("Hello World!， 大家好 ");
            echo "伺服器上的時間為" . date(" Y/m/d H:i:s") ;
       ?>
  </body>      
</html>