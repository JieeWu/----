<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod05/array01.php</title>
  </head>
  <body>
<?php
       $crr = array(123, 3.14, "你", "我", '他'); 
       print_r($crr);
       echo "<hr>";
       echo "第一個元素: $crr[0] <br>";
       echo "第二個元素: $crr[1] <br>";
       echo "第五個元素: $crr[4] <br>";
?>
</body> 
</html>
