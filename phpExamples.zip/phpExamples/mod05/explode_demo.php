<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<title>mod05/explode_demo.php</title>
</head>
<?php
$str='one|two|three|four';
$arr1 = explode('|', $str) ; 
print_r($arr1);
?>
<body>
</body>
</html>
