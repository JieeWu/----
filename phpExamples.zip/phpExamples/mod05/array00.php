<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod05/array00.php</title>
  </head>
  <body>
<?php
   $arr = array(123,  3.14, "你", "我",  '他');
   $brr = array(25 => "Kitty", 100 => "snoopy", 10 => 0.35); 
   $crr = array("識別字串1" => 3.14, "Key99"=>"花仙子", 10=>0.35); 
   print_r($arr);
   echo "<hr>";
   print_r($brr);
   echo "<hr>";   
   print_r($crr);
   echo "<hr>";
?>
</body> 
</html>
