<!DOCTYPE html>
<html>
  <head>
     <meta charset='utf-8'>
     <title>mod05/array2D00.php</title>
  </head>
  <body>
<?php
   $x = array(
           array(101, 99,  28),
           array( 45,108, 125),
           array( 60,241, 400),
           array( 20,300, 254)
        ) ; 
   
   echo "<hr>";

?>
</body> 
</html>
